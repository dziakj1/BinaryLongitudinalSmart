MakeCovarianceMatrix<-function(nObs,form,rho) {
    stopifnot(abs(rho)<=1);
    form <- tolower(form);
    if (form=="iid" || form=="independence" || form=="independent" || rho==0) {
        answer<-diag(rep(1,nObs));
        }
    else if (form=="ar1" || form=="ar-1") {
        answer<-matrix(0,nObs,nObs);
        for (i in 1:nObs)
            for (j in 1:nObs) 
                {answer[i,j]<-rho^abs(i-j);}
        }
    else if (form=="ec" || form=="exch" || form=="exchangeable") {
        answer<-diag(rep(1-rho,nObs))+matrix(rho,nObs,nObs);
    }
    else if (form=="checkerboard") {
        answer<-matrix(0,nObs,nObs);
        for (i in 1:nObs) {
            for (j in 1:nObs) {
                answer[i,j]<-(i+j+1)%%2;
            }
        }
        answer<-rho*answer+(1-rho)*diag(rep(1,nObs));
    }
    else if (form=="ar2") {
        answer<-matrix(0,nObs,nObs);
        for (i in 1:nObs) {
            for (j in 1:nObs) {
                answer[i,j]<-(rho[1]^abs(i-j))+ifelse(abs(i-j)>1,rho[2]^(abs(i-j)-1),0);
            }
        }
    }    
    else if (form=="dual") {
        answer<-matrix(0,nObs,nObs);
        for (i in 1:nObs) {
            for (j in 1:nObs) {
                answer[i,j]<-(rho[1]^abs(i-j))+ifelse(abs(i-j)>0,rho[2],0);
            }
        }
    }        
    else  {answer<-NULL;};
    return(answer);
}

