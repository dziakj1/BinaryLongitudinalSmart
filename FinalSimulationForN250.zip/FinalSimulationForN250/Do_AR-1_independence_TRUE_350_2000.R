rm(list=ls(all=TRUE));
TrueStructure <- 'AR-1';
WorkingCorrelation <- 'independence';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 350;
source('MainCode.R');
