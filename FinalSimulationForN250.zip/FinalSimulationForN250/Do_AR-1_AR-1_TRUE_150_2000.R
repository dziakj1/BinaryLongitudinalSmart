rm(list=ls(all=TRUE));
TrueStructure <- 'AR-1';
WorkingCorrelation <- 'AR-1';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 150;
source('MainCode.R');
