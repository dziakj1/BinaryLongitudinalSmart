DetermineEstimandTrueValues <- function (TrueConditionalBeta,
                                         Male,
                                         BaselineSeverity) {
  
TrueConditionalProbabilities <- matrix(0,6,6);
colnames(TrueConditionalProbabilities) <- paste("Time",1:6,sep="");
row <- 0;
NamesForRows <- NULL;


A1 <- c(1,1,1,-1,-1,-1);
A2 <- c(0,1,-1,0,1,-1);
R <- c(1,0,0,1,0,0);
S1 <- c(.5,rep(1.5,5));
S2 <- c(0,0,1:4);
nu <- matrix(NA,6,6);
for (t in 1:6) {
  nu[,t] <- cbind(1,Male,BaselineSeverity,S1[t],S2[t],R,S1[t]*A1,S2[t]*A1,S2[t]*A2,S1[t]*R,S2[t]*R,S2[t]*A1*A2,S1[t]*R*A1,S2[t]*R*A1) %*% TrueConditionalBeta;
}
TrueConditionalProbabilities <- inverse.logit(nu);
rownames(TrueConditionalProbabilities) <- paste(A1,R,A2);
colnames(TrueConditionalProbabilities) <- paste("Time",1:6,sep="");

TrueMarginalProbabilities <- matrix(0,4,6);
colnames(TrueMarginalProbabilities) <- paste("Time",1:6,sep="");
rownames(TrueMarginalProbabilities) <- c("1 1","1 -1", "-1 1","-1 -1");
row <- 0;
NamesForRows <- NULL;
for (this.A1 in c(+1,-1)) { 
  ProbREquals1 <- ifelse(this.A1==1,ProbRespondGivenPlus,ProbRespondGivenMinus);
  ProbREquals0 <- 1-ProbREquals1;
  for (this.A2 in c(+1,-1)) { 
    row <- row + 1;  
    ProbsIf0 <- TrueConditionalProbabilities[which(A1==this.A1 & A2==this.A2 & R==0),]; 
    ProbsIf1 <- TrueConditionalProbabilities[which(A1==this.A1 & R==1),];
    TrueMarginalProbabilities[row,] <- ProbREquals0 * ProbsIf0 + ProbREquals1 * ProbsIf1;
    NamesForRows <- c(NamesForRows, paste(this.A1,this.A2));
  }
}
rownames(TrueMarginalProbabilities) <- NamesForRows;

print(TrueConditionalProbabilities);
print(TrueMarginalProbabilities);

return(list(TrueConditionalProbabilities=TrueConditionalProbabilities,
            TrueMarginalProbabilities=TrueMarginalProbabilities));
}
