rm(list=ls(all=TRUE));
path <- "C:\\Users\\jjd264\\Documents\\LongitudinalSmart\\BinaryPaper\\NewSimulation\\";
mainname <- "Do";
NSimulations <- 2000;

writeFile <- function() {
  rawfilename <- paste(mainname,"_",
                       TrueStructure,"_",
                       WorkingCorrelation,"_",
                       EstimateWeights,"_",
                       SampleSize,"_",
                       NSimulations,sep="");
  print(rawfilename)
  rfilename <- paste(path,rawfilename,".R",sep="");
  write(x="rm(list=ls(all=TRUE));",file=rfilename,append=FALSE);
  write(x=paste("TrueStructure <- '",TrueStructure,"';",sep=""),file=rfilename,append=TRUE);
  write(x=paste("WorkingCorrelation <- '",WorkingCorrelation,"';",sep=""),file=rfilename,append=TRUE);
  write(x=paste("EstimateWeights <- ",EstimateWeights,";",sep=""),file=rfilename,append=TRUE);
  write(x=paste("NSimulations <- ",NSimulations,";",sep=""),file=rfilename,append=TRUE);
  write(x=paste("SampleSize <- ",SampleSize,";",sep=""),file=rfilename,append=TRUE);
  write(x="source('MainCode.R');",file=rfilename,append=TRUE);
}

#### Ordinary sample size
for (SampleSize in c(150, 250, 350)) {
  if (SampleSize==250) {
    for (TrueStructure in c("independence","exchangeable","AR-1","checkerboard")) {
      for (WorkingCorrelation in c("independence","exchangeable","AR-1")) {
        for (EstimateWeights in c(TRUE,FALSE)) {
          writeFile();
        }
      }
    }
  } else {
    TrueStructure <- "AR-1";
    for (WorkingCorrelation in c("independence","AR-1")) {
      for (EstimateWeights in c(TRUE,FALSE)) {
        writeFile();
      }      
    }
  }
}



