rm(list=ls(all=TRUE));
TrueStructure <- 'exchangeable';
WorkingCorrelation <- 'exchangeable';
EstimateWeights <- FALSE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
