library(geepack);
library(bindata);
source("DefineMultipliersToGetMarginalMeans.R");
source("MakeCovarianceMatrix.R");
source("SimulateNewDataset.R");
source("DetermineEstimandTrueValues.R");
source("DoEstimationKnownWeightsBinary.R");
source("DoEstimationEstimatedWeightsBinary.R");
inverse.logit <- function(t) {return(exp(t)/(1+exp(t)))};
show.sign <- function(t) {return(ifelse(t<0,toString(t),paste("+",toString(t),sep="")))};
set.seed(16802);

# Define the true values for the data-generating model...;
CorParameter <- 0.5;
ProbRespondGivenPlus=0.71;
ProbRespondGivenMinus=0.65;
TrueConditionalBetaValuesAlcohol <- c( 0.687, 0.041, -0.052, -0.490, 0.163, 
                                       0.236, -0.068, -0.140,  0.040, 0.555,
                                       -0.120,  0.058, -0.201, 0.141);  # from alcohol variable;
names(TrueConditionalBetaValuesAlcohol) <- c("(Intercept)","Male","BaselineSeverity","S1","S2",
                                             "R","S1:A1","S2:A1","S2:A2","S1:R",
                                             "S2:R","S2:A1:A2","S1:R:A1","S2:R:A1");
TrueMeanBaselineSeverityAlcohol <- 8.7;
TrueConditionalBetaValuesCocaine <- c( 1.829, 0.082, -0.106, -0.773, 0.086,
                                       -0.129,  0.116, -0.128, -0.019, 0.676,
                                       0.028, -0.079, -0.073, 0.042);  # from cocaine variable;
names(TrueConditionalBetaValuesCocaine) <- names(TrueConditionalBetaValuesAlcohol);
TrueMeanBaselineSeverityCocaine <- 6.4;
TrueConditionalBeta <- TrueConditionalBetaValuesAlcohol;  # could have used the ones from cocaine;
TrueMeanBaselineSeverity <- TrueMeanBaselineSeverityAlcohol;  # could have used the one from cocaine;

# Create data structures to contain the results...;
SampleMeans <- matrix(1,NSimulations,6);
PopulationMeans<- matrix(1,NSimulations,6);
MarginalMeanBias <- rep(NA,NSimulations);
MarginalMeanMSE <- rep(NA,NSimulations);
MarginalMeanCoverage <- rep(NA,NSimulations);
MarginalMeanCoverageCorrected <- rep(NA,NSimulations);
PairwiseAUCBias <- rep(NA,NSimulations);
PairwiseAUCMSE <- rep(NA,NSimulations);
PairwiseAUCCoverage <- rep(NA,NSimulations);
PairwiseAUCCoverageCorrected <- rep(NA,NSimulations);
PairwiseAUCPower <- rep(NA,NSimulations);
PairwiseAUCPowerCorrected <- rep(NA,NSimulations);
CorrelationEstimates <- rep(NA,NSimulations);


# Calculate and record the marginal true values...;
trueValues1 <- DetermineEstimandTrueValues(TrueConditionalBeta=TrueConditionalBeta,
                                           Male=1,
                                           BaselineSeverity=1); 
TrueMarginalMeansAsMatrix <- trueValues1$TrueMarginalProbabilities;
TrueMarginalMeansAsVector <- as.vector(t(TrueMarginalMeansAsMatrix));
# These are marginal over R, but still assuming a particular value of the baseline covariates;

# Start the main simulation loop...;
StartTime <- Sys.time();

for (ThisSimulation in 1:NSimulations) {
  # Simulate the data...;    
  DataWideFormat <- SimulateNewDataset(N=SampleSize,   
                                       TrueConditionalBeta=TrueConditionalBeta,
                                       ProbRespondGivenPlus=ProbRespondGivenPlus,    # P(R = 1 | A_1 = +1)
                                       ProbRespondGivenMinus=ProbRespondGivenMinus,  # P(R = 1 | A_1 = -1)
                                       MeanBaselineSeverity=TrueMeanBaselineSeverity,
                                       TrueStructure=TrueStructure,
                                       CorParameter= 0.5);
  
  SampleMeans[ThisSimulation,] <- apply(DataWideFormat[,paste("Y",1:6,sep="")],2,mean);
  PopulationMeans[ThisSimulation,] <- apply(DataWideFormat[,paste("mu",1:6,sep="")],2,mean);
  # Do the estimation procedure of Lu et al (2016)...;
  if (EstimateWeights) {
    results1 <- DoEstimationEstimatedWeightsBinary(DataWideFormat=DataWideFormat,
                                                   WorkingCorrelation=WorkingCorrelation);
  } else {
    results1 <- DoEstimationKnownWeightsBinary(DataWideFormat=DataWideFormat,
                                               WorkingCorrelation=WorkingCorrelation);
  }
  # Double check that the model coefficients are arranged in the correct order...;
  stopifnot(all.equal(colnames(MultipliersForLinearPredictorsFromMarginalCoefficients),names(results1$beta)))
  colnames(MultipliersForLinearPredictorsFromMarginalCoefficients) <- names(results1$beta);
  # Note: These coefficients are marginal over R, but still assume a particular value of the baseline covariates;
  EstimatedMarginalBeta <- results1$beta;
  CovarianceOfMarginalBetas <- results1$cov.beta;
  if (EstimateWeights) {
    CovarianceOfMarginalBetasCorrected <- results1$cov.beta.corrected;
  } else {
    CovarianceOfMarginalBetasCorrected <- results1$cov.beta;
    
  }
  # Calculate the estimated marginal time-specific fitted values...;
  EstimatedMarginalMeansAsVector <- inverse.logit(MultipliersForLinearPredictorsFromMarginalCoefficients %*% EstimatedMarginalBeta);
  EstimatedMarginalMeansAsMatrix <- matrix(EstimatedMarginalMeansAsVector,
                                           ncol=6, 
                                           byrow=TRUE); 
  colnames(EstimatedMarginalMeansAsMatrix) <- colnames(TrueMarginalMeansAsMatrix);
  # Note: These are marginal over R, but still assume a particular value of the baseline covariates; 
  # Estimate standard errors for the estimated marginal time-specific fitted values...;
  DerivativesOfMeansInLinearPredictors <- diag(as.vector(EstimatedMarginalMeansAsVector * (1-EstimatedMarginalMeansAsVector)));
  CombinedMultipliers <- DerivativesOfMeansInLinearPredictors %*%
    MultipliersForLinearPredictorsFromMarginalCoefficients  ;
  CovarianceOfMarginalMeans <- CombinedMultipliers %*% CovarianceOfMarginalBetas %*% t(CombinedMultipliers);
  CovarianceOfMarginalMeansCorrected <- CombinedMultipliers %*% CovarianceOfMarginalBetasCorrected %*% t(CombinedMultipliers);
  StdErrorsOfMarginalMeans <- sqrt(diag(CovarianceOfMarginalMeans)); 
  StdErrorsOfMarginalMeansCorrected <- sqrt(diag(CovarianceOfMarginalMeansCorrected)); 
  
  # Calculate estimates and estimated standard errors for pairwise contrasts in areas under the curve...;     
  MultipliersForAUCFromMeans <- (c(.5,1,1,1,1,.5)/5);
  MultipliersForPairwiseComparisons <- rbind(cbind(1,-diag(3)),cbind(0,1,-diag(2)),c(0,0,1,-1));
  rownames(MultipliersForPairwiseComparisons) <- c("1vs2","1vs3","1vs4","2vs3","2vs4","3vs4");
  # Note: It is a coincidence that there are six pairwise comparisons (4 choose 2), six observed 
  # time points in the study, and also six cells defined by possible values of A1, A2, and R.;
  CombinedMultipliers <- MultipliersForPairwiseComparisons%x%
    t(MultipliersForAUCFromMeans) %*% 
    DerivativesOfMeansInLinearPredictors %*%
    MultipliersForLinearPredictorsFromMarginalCoefficients  ;
  CovarianceOfPairwiseComparisonsInAUCs <- CombinedMultipliers %*% CovarianceOfMarginalBetas %*% t(CombinedMultipliers);
  StdErrorsOfPairwiseComparisonsInAUCs <- sqrt(diag(CovarianceOfPairwiseComparisonsInAUCs));
  CovarianceOfPairwiseComparisonsInAUCsCorrected <- CombinedMultipliers %*% CovarianceOfMarginalBetasCorrected %*% t(CombinedMultipliers);
  StdErrorsOfPairwiseComparisonsInAUCsCorrected <- sqrt(diag(CovarianceOfPairwiseComparisonsInAUCsCorrected));
  TrueAUCsAsMatrix <- TrueMarginalMeansAsMatrix%*%MultipliersForAUCFromMeans;
  EstimatedAUCsAsMatrix <- EstimatedMarginalMeansAsMatrix%*%MultipliersForAUCFromMeans;
  TruePairwiseComparisonsInAUCs <-  MultipliersForPairwiseComparisons%*%TrueAUCsAsMatrix;
  EstimatedPairwiseComparisonsInAUCs <- MultipliersForPairwiseComparisons%*%EstimatedAUCsAsMatrix;
  
  # Calculate performance measures...;
  MarginalMeanBias[ThisSimulation] <- mean(EstimatedMarginalMeansAsVector-TrueMarginalMeansAsVector);
  MarginalMeanMSE[ThisSimulation] <- mean((EstimatedMarginalMeansAsVector-TrueMarginalMeansAsVector)^2);
  MarginalMeanCoverage[ThisSimulation] <- mean(abs(EstimatedMarginalMeansAsVector-TrueMarginalMeansAsVector)<
                                                 1.96*StdErrorsOfMarginalMeans);
  MarginalMeanCoverageCorrected[ThisSimulation] <- mean(abs(EstimatedMarginalMeansAsVector-TrueMarginalMeansAsVector)<
                                                          1.96*StdErrorsOfMarginalMeansCorrected);
  
  CorrelationEstimates[ThisSimulation] <- results1$CorrelationEstimate;
  PairwiseAUCBias[ThisSimulation] <- mean(EstimatedPairwiseComparisonsInAUCs-TruePairwiseComparisonsInAUCs);
  PairwiseAUCMSE[ThisSimulation] <- mean((EstimatedPairwiseComparisonsInAUCs-TruePairwiseComparisonsInAUCs)^2);
  PairwiseAUCCoverage[ThisSimulation] <- mean(abs(EstimatedPairwiseComparisonsInAUCs-TruePairwiseComparisonsInAUCs)<
                                                1.96*StdErrorsOfPairwiseComparisonsInAUCs);
  PairwiseAUCCoverageCorrected[ThisSimulation] <- mean(abs(EstimatedPairwiseComparisonsInAUCs-TruePairwiseComparisonsInAUCs)<
                                                         1.96*StdErrorsOfPairwiseComparisonsInAUCsCorrected);
  NonnegligibleContrasts <- as.vector(which(abs(TruePairwiseComparisonsInAUCs)>.1));
  PairwiseAUCPower[ThisSimulation] <- mean(abs(EstimatedPairwiseComparisonsInAUCs[NonnegligibleContrasts])>
                             1.96*StdErrorsOfPairwiseComparisonsInAUCs[NonnegligibleContrasts]);
  PairwiseAUCPowerCorrected[ThisSimulation] <- mean(abs(EstimatedPairwiseComparisonsInAUCs[NonnegligibleContrasts])>
                                             1.96*StdErrorsOfPairwiseComparisonsInAUCsCorrected[NonnegligibleContrasts]);
  
  
  
}
FinishTime <- Sys.time();



answers <- data.frame(  TrueStructure=TrueStructure,
                        WorkingCorrelation=WorkingCorrelation,
                        NSimulations=NSimulations,
                        EstimateWeights=EstimateWeights,
                        N=SampleSize,
                        Time=difftime(FinishTime,StartTime,
                                      units="mins"),
                        SampleMean1=mean(SampleMeans[,1]),
                        PopulationMean1=mean(PopulationMeans[,1]),
                        SampleMean2=mean(SampleMeans[,2]),
                        PopulationMean2=mean(PopulationMeans[,2]),
                        SampleMean6=mean(SampleMeans[,6]),
                        PopulationMean6=mean(PopulationMeans[,6]),
                        MarginalMeanBias=mean(MarginalMeanBias), 
                        MarginalMeanMSE=mean(MarginalMeanMSE),
                        MarginalMeanRMSE=sqrt(mean(MarginalMeanMSE)), 
                        MarginalMeanCoverage=mean(MarginalMeanCoverage),
                        MarginalMeanCoverageCorrected=mean(MarginalMeanCoverageCorrected),
                        PairwiseAUCBias = mean(PairwiseAUCBias),
                        PairwiseAUCMSE = mean(PairwiseAUCMSE), 
                        PairwiseAUCRMSE = sqrt(mean(PairwiseAUCMSE)), 
                        PairwiseAUCCoverage = mean(PairwiseAUCCoverage),
                        PairwiseAUCCoverageCorrected = mean(PairwiseAUCCoverageCorrected),
                        PairwiseAUCPower = mean(PairwiseAUCPower),
                        PairwiseAUCPowerCorrected = mean(PairwiseAUCPowerCorrected),
                        CorrelationEstimate = mean(CorrelationEstimates));
print("Answers:");
print.table(answers);

save.image(paste("Saved_",
                 TrueStructure,"_",
                 WorkingCorrelation,"_",
                 EstimateWeights,"_",
                 NSimulations,
                 ".rdata",sep=""));



