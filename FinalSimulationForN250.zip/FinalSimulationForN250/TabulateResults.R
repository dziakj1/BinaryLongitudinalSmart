rm(list = ls()); 
NSimulations <- 2000;
SampleSize <- 250;
AllAnswers <- NULL; 
for (TrueStructure in c("independence","exchangeable","AR-1","checkerboard")) {
  for (WorkingCorrelation in c("independence","exchangeable","AR-1")) {
    for (EstimateWeights in c(TRUE,FALSE)) {
      infilename <- paste("Saved","_",
                           TrueStructure,"_",
                          WorkingCorrelation,"_", 
                          EstimateWeights,"_",
                           NSimulations,".RData",sep="");
      print(infilename);
      if (file.exists(infilename)) {load(infilename)};
      AllAnswers <- rbind(AllAnswers,answers);
    }
  }
}
print(AllAnswers);

print(sum(AllAnswers$Time));
print(sum(AllAnswers$Time)/60/24);

print(sum(AllAnswers$NSimulations));

print(max(abs(AllAnswers$MarginalMeanSimulatedBias)));
print(max(abs(AllAnswers$PairwiseAUCBias)));

print(summary(AllAnswers$MarginalMeanSimulatedCoverage));
print(summary(AllAnswers$PairwiseAUCCoverage));

table4 <- list();
row <- 0;
for (EstimateWeights in c(FALSE,TRUE)) {
  for (WorkingCorrelation in c("independence","exchangeable","AR-1")) {
    print(paste(EstimateWeights,WorkingCorrelation));
    row <- row + 1;
    table4[[row]] <- (AllAnswers[which(AllAnswers$EstimateWeights==EstimateWeights & AllAnswers$WorkingCorrelation==WorkingCorrelation),
                     c("TrueStructure","PairwiseAUCCoverage")]);   
  }
}
print(table4);



table5 <- list();
row <- 0;
for (EstimateWeights in c(FALSE,TRUE)) {
  for (WorkingCorrelation in c("independence","exchangeable","AR-1")) {
    print(paste(EstimateWeights,WorkingCorrelation));
    row <- row + 1;
    table5[[row]] <- (AllAnswers[which(AllAnswers$EstimateWeights==EstimateWeights & AllAnswers$WorkingCorrelation==WorkingCorrelation),
                                 c("TrueStructure","PairwiseAUCRMSE")]);   
  }
}
print(table5);
print(summary(AllAnswers$PairwiseAUCRMSE[which(AllAnswers$EstimateWeights==FALSE)]));
print(summary(AllAnswers$PairwiseAUCRMSE[which(AllAnswers$EstimateWeights==TRUE)]));

