DoEstimationKnownWeightsBinary <- function(DataWideFormat, 
                                           WorkingCorrelation) {
  # Create known weights;
  DataWideFormat$KnownWeight1 <- 2;
  DataWideFormat$KnownWeight2 <- 2*(DataWideFormat$R==0)+1*(DataWideFormat$R==1);  
  # that is, IF (R = 0) THEN KnownWeight2 = 2; ELSE KnownWeight2 = 1;
  DataWideFormat$KnownWeight <- DataWideFormat$KnownWeight1 * DataWideFormat$KnownWeight2; 
  # Translate wide-format dataset into a long-format dataset;
  nwaves <- 6; 
  DataLongFormat <- reshape(DataWideFormat, 
                            varying = c("Y1", "Y2", "Y3", "Y4", "Y5", "Y6"), 
                            v.names = "Y",
                            timevar = "time", 
                            times = c(1, 2, 3, 4, 5, 6), 
                            new.row.names = 1:(nwaves*nrow(DataWideFormat)),
                            direction = "long");
  # Create "replications.";
  # Replicate people who got A1=+1 and responded with R=1.  They were not
  # re-randomized, so we have to replicate their data to inform both of
  # the dynamic treatment regimens which they could have received had they
  # been re-randomized.  It is somewhat as if we are creating two clones of
  # each of them and counting each in a different treatment, because in
  # reality it is indistinguishable which one they received.
  DataLongFormat$ActualTime <- DataLongFormat$time; # because we will mess with the time variable;
  RowsToReplicate <- DataLongFormat[which(DataLongFormat$R==1),];
  RowsNotToReplicate <- DataLongFormat[which(DataLongFormat$R==0),];
  PlusOnePseudodata <- RowsToReplicate;
  PlusOnePseudodata$A2 <- 1;
  MinusOnePseudodata <- RowsToReplicate;
  MinusOnePseudodata$A2 <- -1;
  MinusOnePseudodata$time <- MinusOnePseudodata$time + nwaves;  
  # We keep the same subject ID to show that we don't really have all those
  # new participants.  So we have to distinguish the new observations somehow,
  # and so we treat them as new waves of data on the same person.  Although
  # it seems very ad-hoc, this method has been shown to be valid.
  # Create the final analysis dataset including replicates.
  DataForAnalysis <- rbind(PlusOnePseudodata, MinusOnePseudodata, RowsNotToReplicate);
  DataForAnalysis <- DataForAnalysis[order(DataForAnalysis$id,DataForAnalysis$time),] 
  # This sorts by the variables id and time;
  DataForAnalysis$S1 <- ifelse(DataForAnalysis$ActualTime>1,1.5,.5); 
  DataForAnalysis$S2 <- pmax(DataForAnalysis$ActualTime-2,0);
  #      S1 and S2 here represent the coding of time used for the ENGAGE study.
  #      In your own study, you will probably have to code time differently.
  #      S1(t) should be the amount of time that elapses between first randomization and time t.
  #      S2(t) should be the amount of time that elapses between re-randomization and time t.
  #      In the ENGAGE study this was:
  #        Time   1    2    3    4    5    6 
  #      S1     0.5  1.5  1.5  1.5  1.5  1.5 
  #      S2     0.0  0.0  1.0  2.0  3.0  4.0 
  DataForAnalysis$wave <- DataForAnalysis$time; 
  GEEModelFormula <- Y ~ Male + BaselineSeverity +
    S1 + S2 + S1:A1 + S2:A1 + S2:A2 + 
    S2:A1:A2 ;  # note, averages over R;
  #  Do analysis with GEE
  GEEIndependent <- geeglm(formula = GEEModelFormula,  
                           family=binomial,
                           id=id,  
                           weights = KnownWeight,
                           data=DataForAnalysis,
                           corstr = "independence" ); 
  if (tolower(WorkingCorrelation)=="independence") {
    GEEFinal <- GEEIndependent;
    rho <- 0; 
    BlockWorkCorr <- diag(as.vector(rep(1,nwaves))); 
  } else {
    # "Estimate marginal residual variance under each regime" 
    stopifnot(length(GEEIndependent$resid)==nrow(DataForAnalysis)); # make sure that geeglm didn't drop any rows because of missing data;
    # Create a table of estimated variances indexed by A1, A2, and ActualTime.;
    VarianceEstimatesByRegimenAndTime <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                     A2=unique(DataForAnalysis$A2),
                                                     ActualTime=unique(DataForAnalysis$ActualTime),
                                                     VarianceEstimate=NA);
    for (i in 1:nrow(VarianceEstimatesByRegimenAndTime)) {
      TheseRows <- which( (DataForAnalysis$A1==VarianceEstimatesByRegimenAndTime$A1[i])&
                            (DataForAnalysis$A2==VarianceEstimatesByRegimenAndTime$A2[i])&
                            (DataForAnalysis$ActualTime==VarianceEstimatesByRegimenAndTime$ActualTime[i]) );   
      VarianceEstimatesByRegimenAndTime$VarianceEstimate[i] <- 
        weighted.mean(x=(GEEIndependent$resid[TheseRows]^2),w=DataForAnalysis$KnownWeight[TheseRows]);
    }  
    # Now create a smaller table of estimated variances indexed only by A1 and A2.
    CovarianceEstimatesByRegimen <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                A2=unique(DataForAnalysis$A2), 
                                                VarianceEstimate=NA,
                                                CrossCorrelationEstimate=NA);
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {
      TheseRows <- which( (VarianceEstimatesByRegimenAndTime$A1==CovarianceEstimatesByRegimen$A1[i])&
                            (VarianceEstimatesByRegimenAndTime$A2==CovarianceEstimatesByRegimen$A2[i])  );   
      CovarianceEstimatesByRegimen$VarianceEstimate[i] <- 
        mean(VarianceEstimatesByRegimenAndTime$VarianceEstimate[TheseRows]);
    }   
    VarianceEstimatePooled <- mean(CovarianceEstimatesByRegimen$VarianceEstimate);
    # "Estimate off-diagonal within-person correlation"
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {  # regimen index;
      MeanResidualCrossProductsPerSubjectForThisRegimen <- NULL;
      WeightsForThisRegimen <- NULL;
      ThisRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                              (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]));
      if (tolower(WorkingCorrelation)=="exchangeable") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempCrossProducts <- crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen]))[
              upper.tri(crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen])))]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$KnownWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      if (tolower(WorkingCorrelation)=="ar-1") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempVector <- GEEIndependent$resid[ThisSubjectAndRegimen];
            tempCrossProducts <- tempVector[1:(length(tempVector)-1)] * tempVector[2:length(tempVector)]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$KnownWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      CovarianceEstimatesByRegimen$CrossCorrelationEstimate[i] <- weighted.mean(x=MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                                w=WeightsForThisRegimen)/ 
        CovarianceEstimatesByRegimen$VarianceEstimate[i];
    } 
    CrossCorrelationEstimatePooled <- mean(CovarianceEstimatesByRegimen$CrossCorrelationEstimate);
    # Print preliminary results;
    # Construct WorkCorr (working correlation matrix) 
    rho <- CrossCorrelationEstimatePooled;
    if (tolower(WorkingCorrelation)=="exchangeable") {
      BlockWorkCorr <- diag(as.vector(rep(1-rho,nwaves)))+matrix(rho,nwaves,nwaves);
    }
    if (tolower(WorkingCorrelation)=="ar-1") {
      BlockWorkCorr <- matrix(0,nwaves,nwaves);
      for (thisRow in 1:nrow(BlockWorkCorr)) {
        for (thisColumn in 1:ncol(BlockWorkCorr)) {
          BlockWorkCorr[thisRow,thisColumn] <- rho^abs(thisRow-thisColumn);
        }
      }
    }  
    WorkCorr <- rbind(cbind(BlockWorkCorr,0*BlockWorkCorr),cbind(0*BlockWorkCorr,BlockWorkCorr)); 
    WorkCorrAsZCor <- fixed2Zcor(cor.fixed=WorkCorr, 
                                 id=DataForAnalysis$id,  
                                 waves=DataForAnalysis$wave); 
    GEEFinal <- geeglm(formula = GEEModelFormula,  
                       id=id,  
                       family=binomial,
                       weights = KnownWeight,
                       data=DataForAnalysis,
                       corstr = "fixed",
                       zcor=WorkCorrAsZCor);   
    stopifnot(all.equal(names(GEEIndependent$coefficients)[-1],names(GEEFinal$coefficients)[-1]));
  }
  # Convert the regression coefficients estimates into the desired linear contrast estimates.; 
  p <- length(GEEFinal$coefficients)-1;
  n <- nrow(DataWideFormat);
  return(list(GEEFinal=GEEFinal,
              beta=GEEFinal$coefficients,
              cov.beta=(n/(n-p))*GEEFinal$geese$vbeta,
              CorrelationEstimate=rho));
}