rm(list=ls(all=TRUE));
TrueStructure <- 'exchangeable';
WorkingCorrelation <- 'exchangeable';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
