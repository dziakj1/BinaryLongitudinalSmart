rm(list=ls(all=TRUE));
TrueStructure <- 'AR-1';
WorkingCorrelation <- 'AR-1';
EstimateWeights <- FALSE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
