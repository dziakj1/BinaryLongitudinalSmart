load("Saved_exchangeable_independence_TRUE_2000.RData");
print(summary(results1$GEEFinal$model));
weights <- results1$GEEFinal$model[,8];
A2 <- results1$GEEFinal$model[,7];
R <- (A2==0);
hist(weights);
boxplot(weights~R);