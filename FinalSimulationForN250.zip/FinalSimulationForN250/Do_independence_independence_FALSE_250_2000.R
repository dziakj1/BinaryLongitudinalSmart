rm(list=ls(all=TRUE));
TrueStructure <- 'independence';
WorkingCorrelation <- 'independence';
EstimateWeights <- FALSE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
