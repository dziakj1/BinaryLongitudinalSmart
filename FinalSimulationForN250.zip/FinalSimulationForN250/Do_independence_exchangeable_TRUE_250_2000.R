rm(list=ls(all=TRUE));
TrueStructure <- 'independence';
WorkingCorrelation <- 'exchangeable';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
