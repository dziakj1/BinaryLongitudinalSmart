rm(list=ls(all=TRUE));
TrueStructure <- 'independence';
WorkingCorrelation <- 'independence';

OverallStartTime <- Sys.time(); 

EstimateWeights <- TRUE;
NSimulations <- 10;
SampleSize <- 200; 
source('MainCode.R');

EstimateWeights <- FALSE;
NSimulations <- 10;
SampleSize <- 200; 
source('MainCode.R');

OverallFinishTime <- Sys.time();

print(OverallFinishTime-OverallStartTime);
