rm(list=ls(all=TRUE));
TrueStructure <- 'checkerboard';
WorkingCorrelation <- 'exchangeable';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 250;
source('MainCode.R');
