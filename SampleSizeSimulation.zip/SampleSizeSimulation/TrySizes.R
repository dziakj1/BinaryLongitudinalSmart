rm(list=ls(all=TRUE));
TrueStructure <- 'independence';
WorkingCorrelation <- 'independence';
EstimateWeights <- FALSE;
NSimulations <- 10;
SampleSize <- 500;
source('MainCode.R'); 