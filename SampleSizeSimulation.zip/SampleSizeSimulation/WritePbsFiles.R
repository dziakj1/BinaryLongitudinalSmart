rm(list=ls(all=TRUE));
path <- "C:\\Users\\jjd264\\Documents\\LongitudinalSmart\\BinaryPaper\\SampleSizeSimulation\\";
mainname <- "Do";
NSimulations <- 2000;

write(x=" ",file="qsubs.txt",append=FALSE);

WritePBSFile <- function() {
  rawfilename <- paste(mainname,"_",
                       TrueStructure,"_",
                       WorkingCorrelation,"_",
                       EstimateWeights,"_",
                       SampleSize,"_",
                       NSimulations,sep="");
  print(paste("qsub ",rawfilename,".pbs",sep=""));
  pbsfilename <- paste(path,rawfilename,".pbs",sep=""); 
  # PBS file
  write(x="#PBS -A lmc8_a_g_sc_default",file=pbsfilename,append=FALSE);
  write(x="",file=pbsfilename,append=TRUE); 
  write(x="#PBS -l nodes=1",file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(x="#PBS -l pmem=4gb",file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(x=paste("#PBS -l walltime=",walltime,":00:00",sep=""),file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(x="#PBS -j oe",file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(x="module load r/3.4",file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(x=paste("R --vanilla < ",rawfilename,".R > ",rawfilename,".txt",sep=""),file=pbsfilename,append=TRUE);
  write(x="",file=pbsfilename,append=TRUE);
  write(paste("qsub ",rawfilename,".pbs",sep=""),file="qsubs.txt",append=TRUE);
}

for (SampleSize in c(100, 150, 400)) { 
  TrueStructure <- "AR-1";
  walltime <- ceiling(.175*SampleSize);
  for (WorkingCorrelation in c("independence","AR-1")) {
    for (EstimateWeights in c(TRUE,FALSE)) {
      WritePBSFile();
    }
  }
}