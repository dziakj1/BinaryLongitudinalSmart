rm(list=ls(all=TRUE));
TrueStructure <- 'independence';
WorkingCorrelation <- 'independence';

OverallStartTime <- Sys.time(); 

EstimateWeights <- TRUE;
NSimulations <- 50;
SampleSize <- 50; 
source('MainCode.R'); 

OverallFinishTime <- Sys.time();

print(OverallFinishTime-OverallStartTime);
