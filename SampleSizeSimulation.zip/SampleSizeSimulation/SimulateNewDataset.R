SimulateNewDataset <- function(N=200,   # total sample size
                               TrueStructure="AR-1",  # Correlation structure conditional on all covariates including R.;
                               CorParameter= 0.5, # The correlation parameter, conditional on all covariates including R;
                               # ignored if TrueStructure is "independence";
                               TrueConditionalBeta=rep(0,14),
                               ProbRespondGivenPlus=0.75,    # P(R = 1 | A_1 = +1)
                               ProbRespondGivenMinus=0.75,  # P(R = 1 | A_1 = -1)
                               MeanBaselineSeverity=3) {
  NeedToKeepGenerating <- TRUE;
  while (NeedToKeepGenerating) {
    # Generate subject ID:
    id <- 1:N;
    # Generate baseline variables:
    Male <- sample(x=c(-1,1),size=N,replace=TRUE); # randomly either -1 for female or 1 for male;
    BaselineSeverity <- 1+rpois(n=N,lambda=MeanBaselineSeverity); # right-skewed with a mean around 5;
    # this wasn't taken from the data but seems reasonable
    # because the original variable was a count of days nonabstinent;
    # Generate first randomization to A1=+1 or A1=-1 with equal 50% probability:;
    A1 <- sample(x=c(+1,-1),size=N,replace=TRUE);
    # Generate responder status:
    # The variable respond represents $R$, the "response to treatment," and is
    # coded as 0 for no and 1 for yes.  The probability of "response to treatment"
    # depends on A1
    R <- rep(NA,N); # initialize empty vector;
    R[which(A1==+1)] <- rbinom(n=sum(A1==+1), size=1, prob=ProbRespondGivenPlus);
    R[which(A1==-1)] <- rbinom(n=sum(A1==-1), size=1, prob=ProbRespondGivenMinus);
    # Generate second randomization, leaving it as NA for treatment responders.;
    # A2 is the second randomized treatment assignment.  It is assumed to be relevant only for subjects
    # with R=0.  It is +1 or -1 with equal probability for each such subject,
    # and coded as 0 otherwise.
    A2 <- rep(NA,N);
    A2[which(R==0)] <- sample(x=c(+1,-1), size=sum(R==0), replace=TRUE);
    A2[which(R==1)] <- 0;
    # There are six possible cells (treatment paths).  Check that none are empty: 
    people.in.cell.plus.yes <- which(A1==+1 & R==1);
    people.in.cell.plus.no.plus <- which(A1==+1 & A2==+1);
    people.in.cell.plus.no.minus <- which(A1==+1 & A2==-1);
    people.in.cell.minus.yes <- which(A1==-1 & R==1);
    people.in.cell.minus.no.plus <- which(A1==-1 & A2==+1);
    people.in.cell.minus.no.minus <- which(A1==-1 & A2==-1);
    if (min(length(people.in.cell.plus.yes),
            length(people.in.cell.plus.no.plus),
            length(people.in.cell.plus.no.minus),
            length(people.in.cell.minus.yes),
            length(people.in.cell.minus.no.plus),
            length(people.in.cell.minus.no.minus))>0) {
      NeedToKeepGenerating <- FALSE;
    } else {
      NeedToKeepGenerating <- TRUE;
      #The simulated dataset has nobody in at least one of the six cells (treatment paths).
    }
  }
  # Generate Y vectors for each person separately.
  # We generate the responses for each of the N subjects and 6 time points.
  cor.matrix <- MakeCovarianceMatrix(6,form=TrueStructure,rho=CorParameter);
  mu <- matrix(NA,N,6);
  Y <- matrix(NA,N,6); 
  Z <- NULL;
  for (i in 1:N) {
    # First generate Zi, the design matrix for subject i with baseline covariates, treatments, and time;
    Zi <- data.frame(Intercept=1,
                     Male=Male[i],
                     BaselineSeverity=BaselineSeverity[i],
                     S1=c(0.5, 1.5, 1.5, 1.5, 1.5, 1.5),
                     S2=c(0.0, 0.0, 1.0, 2.0, 3.0, 4.0),
                     #      S1 and S2 here represent the coding of time used for the ENGAGE study.
                     #      In your own study, you will probably have to code time differently.
                     #      S1(t) should be the amount of time that elapses between first randomization and time t.
                     #      S2(t) should be the amount of time that elapses between re-randomization and time t.
                     #      In the ENGAGE study this was:
                     #        Time   1    2    3    4    5    6 
                     #      S1     0.5  1.5  1.5  1.5  1.5  1.5 
                     #      S2     0.0  0.0  1.0  2.0  3.0  4.0 
                     R=R[i]);
    # Include interactions in Zi;
    Zi$S1_A1  <- Zi$S1 * A1[i] ;
    Zi$S2_A1 <- Zi$S2 * A1[i];
    Zi$S2_A2 <- Zi$S2 * A2[i];
    Zi$S1_R <- Zi$S1 * Zi$R;
    Zi$S2_R <- Zi$S2 * Zi$R;
    Zi$S2_A1_A2 <- Zi$S2 * A1[i] * A2[i];
    Zi$S1_R_A1 <- Zi$S1 * A1[i] * Zi$R;
    Zi$S2_R_A1 <- Zi$S2 * A1[i] * Zi$R; 
    colnames(Zi)[which(colnames(Zi)=="Intercept")] <- "(Intercept)";
    stopifnot(all.equal(gsub(":","_",names(TrueConditionalBeta)),names(Zi)));
    # Generate probabilities from logistic regression model; 
    probabilities.vector.for.this.subject <- inverse.logit(as.matrix(Zi)%*%as.matrix(TrueConditionalBeta));
    # Generate outcomes from probabilities;
    mu[i,] <-  probabilities.vector.for.this.subject; 
    Y[i,] <-  rmvbin(n=1,
                     margprob=probabilities.vector.for.this.subject,
                     bincorr=cor.matrix); 
  }  
  simulated.data <- data.frame(id,Male,BaselineSeverity,A1,R,A2,
                               mu1=mu[,1],
                               mu2=mu[,2],
                               mu3=mu[,3],
                               mu4=mu[,4],
                               mu5=mu[,5],
                               mu6=mu[,6],
                               Y1=Y[,1],
                               Y2=Y[,2],
                               Y3=Y[,3],
                               Y4=Y[,4],
                               Y5=Y[,5],
                               Y6=Y[,6]);
  cat(".");
  return(simulated.data);
}