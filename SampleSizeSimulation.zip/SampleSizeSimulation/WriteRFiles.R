rm(list=ls(all=TRUE));
path <- "C:\\Users\\jjd264\\Documents\\LongitudinalSmart\\BinaryPaper\\SampleSizeSimulation\\";
mainname <- "Do";
NSimulations <- 2000;

writeFile <- function() {
  rawfilename <- paste(mainname,"_",
                       TrueStructure,"_",
                       WorkingCorrelation,"_",
                       EstimateWeights,"_",
                       SampleSize,"_",
                       NSimulations,sep="");
  print(rawfilename)
  rfilename <- paste(path,rawfilename,".R",sep="");
  write(x="rm(list=ls(all=TRUE));",file=rfilename,append=FALSE);
  write(x=paste("TrueStructure <- '",TrueStructure,"';",sep=""),file=rfilename,append=TRUE);
  write(x=paste("WorkingCorrelation <- '",WorkingCorrelation,"';",sep=""),file=rfilename,append=TRUE);
  write(x=paste("EstimateWeights <- ",EstimateWeights,";",sep=""),file=rfilename,append=TRUE);
  write(x=paste("NSimulations <- ",NSimulations,";",sep=""),file=rfilename,append=TRUE);
  write(x=paste("SampleSize <- ",SampleSize,";",sep=""),file=rfilename,append=TRUE);
  write(x="source('MainCode.R');",file=rfilename,append=TRUE);
}


for (SampleSize in c(100, 150, 400)) { 
  TrueStructure <- "AR-1";
  for (WorkingCorrelation in c("independence","AR-1")) {
    for (EstimateWeights in c(TRUE,FALSE)) {
      writeFile();
    }      
  }
}



