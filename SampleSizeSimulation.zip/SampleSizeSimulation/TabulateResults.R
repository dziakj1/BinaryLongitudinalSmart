rm(list = ls()); 
NSimulations <- 2000;
AllAnswers <- NULL; 
TrueStructure <- "AR-1"
for (SampleSize in c(100,150,250,400)) {
  for (WorkingCorrelation in c("independence","AR-1")) {
    for (EstimateWeights in c(FALSE,TRUE)) {
      infilename <- paste("Saved","_",
                           TrueStructure,"_",
                          WorkingCorrelation,"_", 
                          EstimateWeights,"_",
                          ifelse(SampleSize==250,"",paste(SampleSize,"_",sep="")),
                           NSimulations,".RData",sep="");
      print(infilename);
      if (file.exists(infilename)) {load(infilename)};
      AllAnswers <- rbind(AllAnswers,answers);
    }
  }
}
print(AllAnswers[,c("N",
                 "WorkingCorrelation",
                 "EstimateWeights",
                 "PairwiseAUCBias",             
                 "PairwiseAUCRMSE",
                 "PairwiseAUCCoverage",          
                 "PairwiseAUCCoverageCorrected",
                 "PairwiseAUCPower",
                 "PairwiseAUCPowerCorrected")]);
 