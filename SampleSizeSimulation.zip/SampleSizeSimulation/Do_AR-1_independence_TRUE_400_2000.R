rm(list=ls(all=TRUE));
TrueStructure <- 'AR-1';
WorkingCorrelation <- 'independence';
EstimateWeights <- TRUE;
NSimulations <- 2000;
SampleSize <- 400;
source('MainCode.R');
