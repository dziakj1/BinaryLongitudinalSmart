DoEstimationEstimatedWeightsBinary <- function(DataWideFormat, 
                                               WorkingCorrelation) {
  # Create known weights;
  DataWideFormat$KnownWeight1 <- 2;
  DataWideFormat$KnownWeight2 <- 2*(DataWideFormat$R==0)+1*(DataWideFormat$R==1);  
  # that is, IF (R = 0) THEN KnownWeight2 = 2; ELSE KnownWeight2 = 1;
  DataWideFormat$KnownWeight <- DataWideFormat$KnownWeight1 * DataWideFormat$KnownWeight2; 
  # Create estimated weights.;
  # Estimate Stage 1 weight:
  DataWideFormat$A1DummyCoded <- 0*(DataWideFormat$A1==-1)+1*(DataWideFormat$A1==+1);
  logisticModel1 <- glm(formula=A1DummyCoded ~  Male + BaselineSeverity, 
                        family=binomial,
                        data=DataWideFormat);
  DataWideFormat$p1 <- fitted(logisticModel1);
  DataWideFormat$EstimatedWeight1 <- DataWideFormat$A1DummyCoded/DataWideFormat$p1 +
    (1-DataWideFormat$A1DummyCoded)/(1-DataWideFormat$p1);
  # Estimate Stage 2 weight:
  DataWideFormat$A2DummyCoded <- 0*(DataWideFormat$A2==-1)+1*(DataWideFormat$A2==+1);
  DataWideFormat$A2DummyCoded[which(DataWideFormat$R==1)] <- NA;
  # responders were not re-randomized, so A2 is neither -1 nor +1;
  logisticModel2 <- glm(formula=A2DummyCoded ~ 
                          Y1 + Male + BaselineSeverity, 
                        family=binomial,
                        na.action=na.exclude,
                        data=DataWideFormat); 
  DataWideFormat$p2 <- fitted(logisticModel2);
  DataWideFormat$EstimatedWeight2 <- 1;     
  who.responded <- which(DataWideFormat$R==0);
  DataWideFormat$EstimatedWeight2[who.responded] <- 
    DataWideFormat$A2DummyCoded[who.responded]/DataWideFormat$p2[who.responded] +
    (1-DataWideFormat$A2DummyCoded[who.responded])/(1-DataWideFormat$p2[who.responded]);
  # Responders have a stage 2 weight of 1;  nonresponders have a stage 2 weighted which is their
  # estimated probability of getting the treatment they did in fact get.
  DataWideFormat$EstimatedWeight <- DataWideFormat$EstimatedWeight1 * DataWideFormat$EstimatedWeight2;
  # Translate wide-format dataset into a long-format dataset;
  nwaves <- 6; 
  DataLongFormat <- reshape(DataWideFormat, 
                            varying = c("Y1", "Y2", "Y3", "Y4", "Y5", "Y6"), 
                            v.names = "Y",
                            timevar = "time", 
                            times = c(1, 2, 3, 4, 5, 6), 
                            new.row.names = 1:(nwaves*nrow(DataWideFormat)),
                            direction = "long");
  # Create "replications.";
  # Replicate people who got A1=+1 and responded with R=1.  They were not
  # re-randomized, so we have to replicate their data to inform both of
  # the dynamic treatment regimens which they could have received had they
  # been re-randomized.  It is somewhat as if we are creating two clones of
  # each of them and counting each in a different treatment, because in
  # reality it is indistinguishable which one they received.
  DataLongFormat$ActualTime <- DataLongFormat$time; # because we will mess with the time variable;
  RowsToReplicate <- DataLongFormat[which(DataLongFormat$R==1),];
  RowsNotToReplicate <- DataLongFormat[which(DataLongFormat$R==0),];
  PlusOnePseudodata <- RowsToReplicate;
  PlusOnePseudodata$A2 <- 1;
  MinusOnePseudodata <- RowsToReplicate;
  MinusOnePseudodata$A2 <- -1;
  MinusOnePseudodata$time <- MinusOnePseudodata$time + nwaves;  
  # We keep the same subject ID to show that we don't really have all those
  # new participants.  So we have to distinguish the new observations somehow,
  # and so we treat them as new waves of data on the same person.  Although
  # it seems very ad-hoc, this method has been shown to be valid.
  # Create the final analysis dataset including replicates.
  DataForAnalysis <- rbind(PlusOnePseudodata, MinusOnePseudodata, RowsNotToReplicate);
  DataForAnalysis <- DataForAnalysis[order(DataForAnalysis$id,DataForAnalysis$time),] 
  # This sorts by the variables id and time;
  DataForAnalysis$S1 <- ifelse(DataForAnalysis$ActualTime>1,1.5,.5); 
  DataForAnalysis$S2 <- pmax(DataForAnalysis$ActualTime-2,0);
  #      S1 and S2 here represent the coding of time used for the ENGAGE study.
  #      In your own study, you will probably have to code time differently.
  #      S1(t) should be the amount of time that elapses between first randomization and time t.
  #      S2(t) should be the amount of time that elapses between re-randomization and time t.
  #      In the ENGAGE study this was:
  #        Time   1    2    3    4    5    6 
  #      S1     0.5  1.5  1.5  1.5  1.5  1.5 
  #      S2     0.0  0.0  1.0  2.0  3.0  4.0 
  DataForAnalysis$wave <- DataForAnalysis$time; 
  GEEModelFormula <- Y ~ Male + BaselineSeverity +
    S1 + S2 + S1:A1 + S2:A1 + S2:A2 + 
    S2:A1:A2 ;  # note, averages over R;
  #  Do analysis with GEE
  
  GEEIndependent <- suppressWarnings(geeglm(formula = GEEModelFormula,  
                                            family=binomial,
                                            id=id,  
                                            weights = EstimatedWeight,
                                            data=DataForAnalysis,
                                            corstr = "independence" )); 
  if (tolower(WorkingCorrelation)=="independence") {
    GEEFinal <- GEEIndependent;
    rho <- 0;
    BlockWorkCorr <- diag(as.vector(rep(1,nwaves)));
  } else {
    # "Estimate marginal residual variance under each regime" 
    stopifnot(length(GEEIndependent$resid)==nrow(DataForAnalysis)); # make sure that geeglm didn't drop any rows because of missing data;
    # Create a table of estimated variances indexed by A1, A2, and ActualTime.;
    VarianceEstimatesByRegimenAndTime <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                     A2=unique(DataForAnalysis$A2),
                                                     ActualTime=unique(DataForAnalysis$ActualTime),
                                                     VarianceEstimate=NA);
    for (i in 1:nrow(VarianceEstimatesByRegimenAndTime)) {
      TheseRows <- which( (DataForAnalysis$A1==VarianceEstimatesByRegimenAndTime$A1[i])&
                            (DataForAnalysis$A2==VarianceEstimatesByRegimenAndTime$A2[i])&
                            (DataForAnalysis$ActualTime==VarianceEstimatesByRegimenAndTime$ActualTime[i]) );   
      VarianceEstimatesByRegimenAndTime$VarianceEstimate[i] <- 
        weighted.mean(x=(GEEIndependent$resid[TheseRows]^2),w=DataForAnalysis$EstimatedWeight[TheseRows]);
    }  
    # Now create a smaller table of estimated variances indexed only by A1 and A2.
    CovarianceEstimatesByRegimen <- expand.grid(A1=unique(DataForAnalysis$A1),
                                                A2=unique(DataForAnalysis$A2), 
                                                VarianceEstimate=NA,
                                                CrossCorrelationEstimate=NA);
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {
      TheseRows <- which( (VarianceEstimatesByRegimenAndTime$A1==CovarianceEstimatesByRegimen$A1[i])&
                            (VarianceEstimatesByRegimenAndTime$A2==CovarianceEstimatesByRegimen$A2[i])  );   
      CovarianceEstimatesByRegimen$VarianceEstimate[i] <- 
        mean(VarianceEstimatesByRegimenAndTime$VarianceEstimate[TheseRows]);
    }   
    VarianceEstimatePooled <- mean(CovarianceEstimatesByRegimen$VarianceEstimate);
    # "Estimate off-diagonal within-person correlation"
    for (i in 1:nrow(CovarianceEstimatesByRegimen)) {  # regimen index;
      MeanResidualCrossProductsPerSubjectForThisRegimen <- NULL;
      WeightsForThisRegimen <- NULL;
      ThisRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                              (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]));
      if (tolower(WorkingCorrelation)=="exchangeable") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempCrossProducts <- crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen]))[
              upper.tri(crossprod(t(GEEIndependent$resid[ThisSubjectAndRegimen])))]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$EstimatedWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      if (tolower(WorkingCorrelation)=="ar-1") {
        for (j in unique(DataForAnalysis$id)) { # subject index; 
          ThisSubjectAndRegimen <- which( (DataForAnalysis$A1==CovarianceEstimatesByRegimen$A1[i])&
                                            (DataForAnalysis$A2==CovarianceEstimatesByRegimen$A2[i]) &
                                            (DataForAnalysis$id==j));
          if (length(ThisSubjectAndRegimen)>0) {
            tempVector <- GEEIndependent$resid[ThisSubjectAndRegimen];
            tempCrossProducts <- tempVector[1:(length(tempVector)-1)] * tempVector[2:length(tempVector)]; 
            MeanResidualCrossProductsPerSubjectForThisRegimen <- c(MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                   mean(tempCrossProducts)); 
            WeightsForThisRegimen <- c(WeightsForThisRegimen, DataForAnalysis[ThisSubjectAndRegimen[1],]$EstimatedWeight);
            # assumes all observations per subject have the same weight;
          }       
        }
      }
      CovarianceEstimatesByRegimen$CrossCorrelationEstimate[i] <- weighted.mean(x=MeanResidualCrossProductsPerSubjectForThisRegimen,
                                                                                w=WeightsForThisRegimen)/ 
        CovarianceEstimatesByRegimen$VarianceEstimate[i];
    } 
    CrossCorrelationEstimatePooled <- mean(CovarianceEstimatesByRegimen$CrossCorrelationEstimate);
    # Print preliminary results;
    # Construct WorkCorr (working correlation matrix) 
    rho <- CrossCorrelationEstimatePooled; 
    if (tolower(WorkingCorrelation)=="exchangeable") {
      BlockWorkCorr <- diag(as.vector(rep(1-rho,nwaves)))+matrix(rho,nwaves,nwaves);
    }
    if (tolower(WorkingCorrelation)=="ar-1") {
      BlockWorkCorr <- matrix(0,nwaves,nwaves);
      for (thisRow in 1:nrow(BlockWorkCorr)) {
        for (thisColumn in 1:ncol(BlockWorkCorr)) {
          BlockWorkCorr[thisRow,thisColumn] <- rho^abs(thisRow-thisColumn);
        }
      }
    }  
    WorkCorr <- rbind(cbind(BlockWorkCorr,0*BlockWorkCorr),cbind(0*BlockWorkCorr,BlockWorkCorr)); 
    WorkCorrAsZCor <- fixed2Zcor(cor.fixed=WorkCorr, 
                                 id=DataForAnalysis$id,  
                                 waves=DataForAnalysis$wave); 
    GEEFinal <- suppressWarnings(geeglm(formula = GEEModelFormula,  
                                        id=id,  
                                        family=binomial,
                                        weights = EstimatedWeight,
                                        data=DataForAnalysis,
                                        corstr = "fixed",
                                        zcor=WorkCorrAsZCor));   
    stopifnot(all.equal(names(GEEIndependent$coefficients)[-1],names(GEEFinal$coefficients)[-1]));
  } 
  nsub <- nrow(DataWideFormat);
  PredictorsLogistic1 <-  DataWideFormat[,c("Male","BaselineSeverity")]; 
  PredictorsLogistic2 <- DataWideFormat[,c("Y1","Male","BaselineSeverity")]; 
  scoreAlpha1 <- cbind(1,PredictorsLogistic1) * (DataWideFormat$A1DummyCoded - DataWideFormat$p1);
  residuals2 <- DataWideFormat$A2DummyCoded - DataWideFormat$p2;
  residuals2[which(is.na(residuals2))] <- 0;  # This excludes the responders from the model for stage 2;
  scoreAlpha2 <- cbind(1,PredictorsLogistic2) * residuals2; 
  # Step 3: Finish calculating the standard errors.
  # This is done with the replicated data. 
  predictors <- cbind(DataForAnalysis$Male,
                      DataForAnalysis$BaselineSeverity,
                      DataForAnalysis$S1,
                      DataForAnalysis$S2,
                      DataForAnalysis$S1*DataForAnalysis$A1,
                      DataForAnalysis$S2*DataForAnalysis$A1,
                      DataForAnalysis$S2*DataForAnalysis$A2,
                      DataForAnalysis$S2*DataForAnalysis$A1*DataForAnalysis$A2);
  predictors <- cbind(1,predictors); # add intercept column;
  # Construct "matrixI," the empirical covariance matrix of the 
  # GEE coefficients, and "matrixJ", their model-based covariance matrix. 
  # "I" and "J" are the notation used in Xi Lu's code (I stands for "information" as in
  # Fisher information matrix.  They don't represent the usual I and J matrices which 
  #	are the identity (diagonal) and all-ones matrix respectively. */
  resid <- GEEFinal$residuals;
  nobs <- nrow(predictors);
  fitted <- GEEFinal$fitted.values;
  fitted[which(fitted<.0000000000001)] <- .0000000000001; 
  fitted[which(fitted>.9999999999999)] <- .9999999999999; 
  stopifnot(length(resid)==nobs); # try to make sure nothing has gone wrong;
  matrixJ <- matrix(0,ncol(predictors),ncol(predictors));
  U <- matrix(0,nsub,ncol(predictors));
  # The rows of U are the score function for each subject (derivative of that subject's
  # log-pseudo-likelihood contribution with respect to beta), with each subject in the original 
  # data set having one row. */   
  indicesNextSubject <- 1:nwaves;  
  for (i in 1:nsub) {
    indicesThisSubject <- indicesNextSubject;
    weightThisSubject <- DataForAnalysis$KnownWeight[indicesThisSubject[1]];
    # The weights are the same for all observations within the 
    # subject, so we just read the first one.
    # I'm following Xi Lu's code in using the known weight here instead of the 
    # estimated weight.  I am not sure why she does this.
    residualsThisSubject <- resid[indicesThisSubject];
    predictorsThisSubject <- predictors[indicesThisSubject,] ;  
    fittedValuesThisSubject <- fitted[indicesThisSubject];
    Mi <- fittedValuesThisSubject*(1-fittedValuesThisSubject); 
    errorThisSubject <- weightThisSubject * t(predictorsThisSubject) %*% 
      diag(as.vector(sqrt(Mi)))%*% 
      solve(BlockWorkCorr) %*% 
      diag(as.vector(1/sqrt(Mi)))%*%
      residualsThisSubject;
    # errorThisSubject is a k by 1 vector for this subject's score function, 
    # here k is ncol(predictors) including intercept. ;
    if (indicesThisSubject[nwaves] == nobs) {
      # This is the case where the current observations are for the last individual,
      # so no more observations are forthcoming. 
      U[i,] <- t(errorThisSubject);
      thisMatrixJ <- weightThisSubject * t(predictorsThisSubject)%*%
        diag(as.vector(sqrt(Mi)))%*% 
        solve(BlockWorkCorr) %*% 
        diag(as.vector(1/sqrt(Mi)))%*%
        predictorsThisSubject;
      # contribution to J from this subject;
      matrixJ <- matrixJ + thisMatrixJ;
    } else {
      if (DataForAnalysis$wave[[indicesThisSubject[nwaves]+1]] == 1) {
        # This is the case where the next observations are from an actual new individual. */
        U[i,] <- t(errorThisSubject);
        thisMatrixJ = weightThisSubject * t(predictorsThisSubject)%*%
          diag(as.vector(sqrt(Mi)))%*% 
          solve(BlockWorkCorr) %*% 
          diag(as.vector(1/sqrt(Mi)))%*%
          predictorsThisSubject;
        # contribution to J from this subject;
        matrixJ <- matrixJ + thisMatrixJ;
        indicesNextSubject <- (indicesThisSubject[nwaves]+1):(indicesThisSubject[nwaves]+nwaves); 
      } 
      if (DataForAnalysis$wave[[indicesThisSubject[nwaves]+1]] == nwaves+1) {
        # This is the case where the next observations are a replicate of this individual.;
        indicesReplicate <- (indicesThisSubject[nwaves]+1):(indicesThisSubject[nwaves]+nwaves);
        residReplicate <- resid[indicesReplicate];
        predictorsReplicate <- predictors[indicesReplicate,];
        errorReplicate <- weightThisSubject * t(predictorsReplicate)%*%
          diag(as.vector(sqrt(Mi)))%*% 
          solve(BlockWorkCorr) %*% 
          diag(as.vector(1/sqrt(Mi)))%*%
          residReplicate;
        U[i,] <- t(errorThisSubject + errorReplicate);
        thisMatrixJ <- weightThisSubject * t(predictorsThisSubject)%*%
          diag(as.vector(sqrt(Mi)))%*% 
          solve(BlockWorkCorr) %*% 
          diag(as.vector(1/sqrt(Mi)))%*%
          predictorsThisSubject + 
          weightThisSubject * t(predictorsReplicate)%*%
          diag(as.vector(sqrt(Mi)))%*% 
          solve(BlockWorkCorr) %*% 
          diag(as.vector(1/sqrt(Mi)))%*%
          predictorsReplicate;
        matrixJ <- matrixJ + thisMatrixJ;
        indicesNextSubject <- (indicesReplicate[nwaves]+1):(indicesReplicate[nwaves]+nwaves);
      }
      if ((DataForAnalysis$wave[indicesThisSubject[nwaves]+1] != 1) & 
          (DataForAnalysis$wave[indicesThisSubject[nwaves]+1] != nwaves+1) ) {
        print("Unexpected error in code or dataset;");
        print(indicesThisSubject); 
      }
    }
  }
  #  Construct the final covariance matrix estimate using an adjusted sandwich formula, 
  # and extract the standard errors.;
  matrixIKnownWeights <- (1/nsub)*t(U)%*%U;
  scores <- as.matrix(cbind(scoreAlpha1, scoreAlpha2));
  if(kappa(t(scores)%*%scores)<1e12) {
     hat <- scores%*%solve(t(scores)%*%scores)%*%t(scores);
  } else {
    hat <- matrix(NA,nrow(scores),nrow(scores));
  }
  # The "hat" or projection matrix of the regression of the weights on the predictors of the weights.
  Uproj <- U - hat%*%U;
  matrixI <- (1/nsub)*t(Uproj)%*%Uproj; 
  matrixJ <- matrixJ/nsub;
  invJ <- solve(matrixJ);              
  p <- length(GEEFinal$coefficients)-1;
  n <- nrow(DataWideFormat);  
  return(list(GEEFinal=GEEFinal,
              beta=GEEFinal$coefficients,
              cov.beta=(n/(n-p))*GEEFinal$geese$vbeta,
              cov.beta.corrected=(1/(n-p))*invJ %*% matrixI %*% invJ,
              CorrelationEstimate=rho));
}